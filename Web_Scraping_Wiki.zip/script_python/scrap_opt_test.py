# Desarrollado por: Camilo Andrés Bedoya Caro
# Analista RPA


import mysql.connector
import time
import os
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException


def encontrar_elemento(driver, espera, locator):
    try:
        return espera.until(EC.presence_of_element_located(locator))
    except TimeoutException:
        print("Error de tiempo de espera")
        raise


def busqueda_raspado_elementos():
    driver = webdriver.Chrome()
    driver.get("https://www.google.com")
    espera = WebDriverWait(driver, 10)

    try:
        caja_busqueda = encontrar_elemento(driver, espera, (By.NAME, "q"))
        caja_busqueda.send_keys("Selenium")
        caja_busqueda.send_keys(Keys.ENTER)
        time.sleep(3)

        link_wikipedia = encontrar_elemento(driver, espera, (By.CSS_SELECTOR, "#rso > div:nth-child(3) > div > div > div.Z26q7c.UK95Uc.jGGQ5e.VGXe8 > div > a"))
        link_wikipedia.click()

        titulo = encontrar_elemento(driver, espera, (By.XPATH,'//*[@id="firstHeading"]/span'))
        texto_titulo = titulo.text

        introduccion = encontrar_elemento(driver, espera, (By.XPATH, '//*[@id="mw-content-text"]/div[1]/p[1]'))
        texto_introduccion = introduccion.text

        historia = encontrar_elemento(driver, espera, (By.XPATH, '//*[@id="mw-content-text"]/div[1]/p[2]'))
        texto_historia = historia.text

        componente = encontrar_elemento(driver, espera, (By.XPATH, '//*[@id="mw-content-text"]/div[1]/p[3]'))
        texto_componente = componente.text

        print("Titulo:", texto_titulo)
        print("\n")
        print("Primer párrafo:", texto_historia)
        print("\n")
        print("Segundo párrafo:", texto_introduccion)
        print("\n")
        print("Tercer párrafo:", texto_componente)

        print("Automatizacion Completada con éxito")

        # Inicializacion de Conexion con MySQL
        iniciar_conexion= mysql.connector.connect(
            host="Localhost",
            user="root",
            password="123456789",
            database="selenium"
        )

        cursor= iniciar_conexion.cursor()

        consulta= "INSERT INTO scrap_wiki (Titulo,Introduccion,Historia,Componente) VALUES (%s,%s,%s,%s)"

        raspado_elementos=(texto_titulo,texto_introduccion,texto_historia,texto_componente)
        cursor.execute(consulta,raspado_elementos) 

        iniciar_conexion.commit()
        if cursor.rowcount > 0:
            print("Los datos fueron enviados y almacenados correctamente.")
        else:
            print("Error: Los datos no fueron enviados.")        
        cursor.close()
        iniciar_conexion.close()

        if cursor.rowcount > 0:
            print("Los datos fueron enviados y almacenados correctamente.")
        else:
            print("Error: Los datos no fueron enviados.")

    except Exception as e:
        print("Error en la obtención de los elementos en la página:", str(e))
        print("No se pudo completar la Operación. Intente de nuevo")
        print("Automatizacion Fallida:", 'Error de tiempo de espera')

    finally:
        driver.quit()

busqueda_raspado_elementos()
